<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.template','data' => []] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('template'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <table>

        <tr>
            <th>Name</th>
            <th>Description</th>
            <th>View</th>
            <th>Download</th>
        </tr>
    
        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    
        <tr>
            <td><?php echo e($data->name); ?></td>
            <td><?php echo e($data->description); ?></td>
            <td><a href="<?php echo e(url('/view',$data->id)); ?>">View</a></td>
            <td><a href="<?php echo e(url('/download',$data->file)); ?>">Download</a></td>
    
    
        </tr>
        
    
    
    
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    
        </table>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\web-app-raziel\resources\views/showproduct.blade.php ENDPATH**/ ?>